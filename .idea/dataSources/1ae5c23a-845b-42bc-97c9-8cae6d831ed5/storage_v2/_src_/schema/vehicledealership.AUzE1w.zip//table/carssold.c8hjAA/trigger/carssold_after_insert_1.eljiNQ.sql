create definer = JAK@localhost trigger CarsSold_AFTER_INSERT_1
    after insert
    on carssold
    for each row
BEGIN
update car
set sold = true
where idcar = car_idcar;
END;

