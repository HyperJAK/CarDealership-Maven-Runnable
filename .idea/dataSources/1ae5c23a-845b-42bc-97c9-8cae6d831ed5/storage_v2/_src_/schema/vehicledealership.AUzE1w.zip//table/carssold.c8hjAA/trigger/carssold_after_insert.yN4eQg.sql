create definer = JAK@localhost trigger CarsSold_AFTER_INSERT
    after insert
    on carssold
    for each row
BEGIN
Update Client
Set carsOwned = carsOwned + 1
Where idclient = Client_idclient;
END;

